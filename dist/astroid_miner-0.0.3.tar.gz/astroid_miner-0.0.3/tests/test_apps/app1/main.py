#!/usr/bin/env python3


def my_function():
    pass


def main():
    pass


if __name__ == '__main__':
    main()
