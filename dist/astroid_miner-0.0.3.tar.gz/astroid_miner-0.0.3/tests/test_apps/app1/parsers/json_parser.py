

class JsonParser:

    def parse(self):
        pass
