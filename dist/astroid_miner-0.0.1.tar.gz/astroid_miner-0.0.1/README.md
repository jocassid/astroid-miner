# astroid-miner
Wrapper around the astroid library to aid in static code analysis
